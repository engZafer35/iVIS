



//
//#include <stdio.h>
//#include <string.h>

/**
 *
// */
//struct myStr
//{
//    int x;
//    char c;
//    char c2;
//    int z;
//    float f;
//};
//
//
//int main (void)
//{
//
//
//
//}
//
