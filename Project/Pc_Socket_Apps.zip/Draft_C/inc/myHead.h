/*
 * myHead.h
 *
 *  Created on: Apr 12, 2021
 *      Author: zafer.satilmis
 */

#ifndef INC_MYHEAD_H_
#define INC_MYHEAD_H_

#define TEST_VAL 3

#endif /* INC_MYHEAD_H_ */
