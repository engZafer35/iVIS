

#include <stdio.h>
#include <string.h>



void foo(int x)
{
    for (unsigned char i = 0; i < 2 * x; ++i)
    {
        printf(" %d \n", i);
    }
}


/*
 * Girilen sayının iki katı kadar sayı print edilmek isteniyor.
 * Aşağıdaki çağrım
 */

//int main(void)
//{
//    foo (150);
//
//    return 0;
//}
