/*
 * test.c
 *
 *  Created on: Oct 1, 2021
 *      Author: zafer.satilmis
 */
#include <stdio.h>


typedef int myint;

typedef struct test
{
    int x;
}test_t;

test_t t;

#define AIRTIES  "airties"


int x;

#define IS_NEGATIVE(x)  !!(x & (1 << sizeof (x))

static void foo(void)
{
    printf("---- Hello Zafer ---- %d", x);
}
