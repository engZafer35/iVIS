

/**
 * Yazılımcı int p; ve void p; pointer olarak tanımlamak isterken hata yapıyor. Ne gibi probler görürüz
 */

//void main (void)
//{
//    int x;
//    int p;
//
//    p = &x;
//
//    // ...
//    // ...
//
//
//}
//
//
//void main (void)
//{
//    int x;
//    void p;
//
//    p = &x;
//
//    // ...
//    // ...
//
//
//}
//
//


