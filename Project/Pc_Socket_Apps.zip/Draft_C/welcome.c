
#include <stdio.h>
#include <string.h>

void sayW(void)
{
    printf("Welcome");
}
void sayT(void)
{
    printf(" to ");
}
void sayA(void)
{
    printf("Airties\n");
}


/*
 * sadece iki satır kod ekleyerek Welcome to Airties çıktısını nasıl görebiliriz.
 * blok bölgesi olan kullanımlarda örneğin if gib blok için de tek bir satır kullanılabilir.
 */
//
//int main()
//{
//
//    return 0;
//}

