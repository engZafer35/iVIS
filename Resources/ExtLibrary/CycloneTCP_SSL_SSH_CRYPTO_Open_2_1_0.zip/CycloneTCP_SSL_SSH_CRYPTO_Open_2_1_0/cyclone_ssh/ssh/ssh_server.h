/**
 * @file ssh_server.h
 * @brief SSH server
 *
 * @section License
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 *
 * Copyright (C) 2019-2021 Oryx Embedded SARL. All rights reserved.
 *
 * This file is part of CycloneSSH Open.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * @author Oryx Embedded SARL (www.oryx-embedded.com)
 * @version 2.1.0
 **/

#ifndef _SSH_SERVER_H
#define _SSH_SERVER_H

//Dependencies
#include "ssh/ssh.h"

//Stack size required to run the SSH server
#ifndef SSH_SERVER_STACK_SIZE
   #define SSH_SERVER_STACK_SIZE 750
#elif (SSH_SERVER_STACK_SIZE < 1)
   #error SSH_SERVER_STACK_SIZE parameter is not valid
#endif

//Priority at which the SSH server should run
#ifndef SSH_SERVER_PRIORITY
   #define SSH_SERVER_PRIORITY OS_TASK_PRIORITY_NORMAL
#endif

//Maximum time the server will wait before closing the connection
#ifndef SSH_SERVER_TIMEOUT
   #define SSH_SERVER_TIMEOUT 60000
#elif (SSH_SERVER_TIMEOUT < 1000)
   #error SSH_SERVER_TIMEOUT parameter is not valid
#endif

//SSH server tick interval
#ifndef SSH_SERVER_TICK_INTERVAL
   #define SSH_SERVER_TICK_INTERVAL 1000
#elif (SSH_SERVER_TICK_INTERVAL < 100)
   #error SSH_SERVER_TICK_INTERVAL parameter is not valid
#endif

//C++ guard
#ifdef __cplusplus
extern "C" {
#endif


/**
 * @brief SSH server settings
 **/

typedef struct
{
   NetInterface *interface;                        ///<Underlying network interface
   uint16_t port;                                  ///<SSH port number
   uint_t numConnections;                          ///<Maximum number of SSH connections
   SshConnection *connections;                     ///<SSH connections
   uint_t numChannels;                             ///<Maximum number of SSH channels
   SshChannel *channels;                           ///<SSH channels
   const PrngAlgo *prngAlgo;                       ///<Pseudo-random number generator to be used
   void *prngContext;                              ///<Pseudo-random number generator context
   SshPasswordAuthCallback passwordAuthCallback;   ///<Password authentication callback
   SshPublicKeyAuthCallback publicKeyAuthCallback; ///<Public key authentication callback
} SshServerSettings;


/**
 * @brief SSH server context
 **/

typedef struct
{
   bool_t running;          ///<Operational state of the SSH server
   bool_t stop;             ///<Stop request
   NetInterface *interface; ///<Underlying network interface
   Socket *socket;          ///<Listening socket
   uint16_t port;           ///<SSH port number
   SshContext sshContext;   ///<SSH context
} SshServerContext;


//SSH server related functions
void sshServerGetDefaultSettings(SshServerSettings *settings);

error_t sshServerInit(SshServerContext *context,
   const SshServerSettings *settings);

error_t sshServerRegisterGlobalRequestCallback(SshServerContext *context,
   SshGlobalReqCallback callback, void *param);

error_t sshServerUnregisterGlobalRequestCallback(SshServerContext *context,
   SshGlobalReqCallback callback);

error_t sshServerRegisterChannelRequestCallback(SshServerContext *context,
   SshChannelReqCallback callback, void *param);

error_t sshServerUnregisterChannelRequestCallback(SshServerContext *context,
   SshChannelReqCallback callback);

error_t sshServerLoadHostKey(SshServerContext *context, const char_t *publicKey,
   size_t publicKeyLen, const char_t *privateKey, size_t privateKeyLen);

error_t sshServerUnloadAllHostKeys(SshServerContext *context);

error_t sshServerStart(SshServerContext *context);
error_t sshServerStop(SshServerContext *context);

void sshServerTask(SshServerContext *context);

void sshServerDeinit(SshServerContext *context);

//C++ guard
#ifdef __cplusplus
}
#endif

#endif
